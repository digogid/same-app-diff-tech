import { Component, OnInit } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  postList = [];
  empty = true;
  constructor() { }
  async ngOnInit() {
    const { data } = await axios.get('https://jsonplaceholder.typicode.com/posts');
    this.postList = data;
    this.empty = false;
  }
}
