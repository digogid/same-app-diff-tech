<template>
  <div class="App">
    <div v-if="empty === true">Não há itens para exibir.</div>
    <p v-else v-for="post in postList" v-bind:key="post.id">
      {{ post.title }}
    </p>
  </div>
</template>

<script>
import axios from 'axios';

export default {
  name: "App",
  data() {
    return {
      postList: [],
      empty: true
    };
  },
  async created() {
    const { data } = await axios.get('https://jsonplaceholder.typicode.com/posts');
    this.postList = data;
    this.empty = false;
  }
};
</script>

<style>
body {
  margin: 0;
  font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", "Roboto", "Oxygen",
    "Ubuntu", "Cantarell", "Fira Sans", "Droid Sans", "Helvetica Neue",
    sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
}

.App {
  text-align: center;
}
</style>
