import React from "react";
import "./App.css";
import axios from "axios";

function App() {
  const result = useAsyncHook();
  return (
    <div className="App">
      {
        result.map(item => {
          return (<p key={item.id}>{item.title}</p>);
        })
      }
    </div>
  );
}

function useAsyncHook() {
  const [result, setResult] = React.useState([]);

  React.useEffect(() => {
    async function getPosts() {
      const { data } = await axios.get(`https://jsonplaceholder.typicode.com/posts`);
      setResult( data );
    }
    getPosts();
    
  });

  return result;
}

export default App;
