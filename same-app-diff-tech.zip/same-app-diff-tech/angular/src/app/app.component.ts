import { Component, OnInit } from '@angular/core';
import axios from 'axios';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent implements OnInit {
  books = [];
  empty = true;
  term = "";
  constructor() { }
  async ngOnInit() {
  }

  async search() {
    const { data } = await axios.get( `https://www.googleapis.com/books/v1/volumes?q=${this.term}`);
    this.books = data.items.map(book => book.volumeInfo);
    this.empty = false;
  }
}
