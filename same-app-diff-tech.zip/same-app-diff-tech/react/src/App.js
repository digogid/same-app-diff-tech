import React, { useState, useCallback } from "react";
import "./App.css";
import axios from "axios";

function App() {

  const [term, setTerm] = useState('');
  const [books, setBooks] = useState([]);
  const [empty, setEmpty] = useState(true);

  const useAsyncHook = useCallback(async() => {
    const { data } = await axios.get( `https://www.googleapis.com/books/v1/volumes?q=${term}`);
    setBooks( data.items.map(book => book.volumeInfo) );
    setEmpty(false);
  })

  return (
    <div className="App">
      <input type="text" onChange={e => setTerm(e.target.value)} />
      <button onClick={useAsyncHook}>Pesquisar</button>
      <section className="container">
      { empty === true ? 
        (<p>Não há itens para exibir.</p>)
        : (
          books.map(book => {
            return (
              <div key={book.title} className="card">
                 <h4>{ book.title }</h4>
                 <img src={book.imageLinks ? book.imageLinks.thumbnail : ''} />
              </div>
            );
          })
          )
        }
      </section>
    </div>
  )
}

export default App;