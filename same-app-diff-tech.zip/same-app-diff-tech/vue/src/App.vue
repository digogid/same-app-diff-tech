<template>
  <div class="App">
    <router-view />
  </div>
</template>

<script>

export default {
  name: "App"  
};
</script>